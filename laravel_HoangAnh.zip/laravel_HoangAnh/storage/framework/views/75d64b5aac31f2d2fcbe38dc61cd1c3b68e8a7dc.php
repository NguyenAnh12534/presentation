

<?php $__env->startSection('content'); ?>
    <section class="p-4 my-container">
        <h1>My Equipments</h1>
        <table class="table">
            <thead class="table-light">
                <tr>
                    <th scope="col">Serial Number</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Category</th>
                </tr>
            </thead>
            <tbody id="equipment-table-body">
                <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($equipment->serial_number); ?>" class="table-row <?php echo e($equipment->category->title); ?>">
                        <th scope="row"><?php echo e($equipment->serial_number); ?></th>
                        <td class="equipName"><?php echo e($equipment->name); ?></td>
                        <td class="equipDesc"><?php echo e($equipment->desc); ?></td>
                        <td class="equipCategory"><?php echo e($equipment->category->title); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hoanganh\wtf1\laravel_HoangAnh\laravel_HoangAnh\resources\views/pages/my_equipments.blade.php ENDPATH**/ ?>