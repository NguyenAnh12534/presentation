

<?php $__env->startSection('content'); ?>
    <section class="p-4 my-container">
        <h1>My Info</h1>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Birthdate</th>
                    <th scope="col">Phone number</th>
                </tr>
            </thead>
            <tbody>
                <tr id="<?php echo e($user->id); ?>">
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td class="userName"><?php echo e($user->name); ?></td>
                    <td class="userEmail"><?php echo e($user->email); ?></td>
                    <td class="userGender"><?php echo e($user->gender ? 'Male' : 'Female'); ?></td>
                    <td class="userBirthdate"><?php echo e($user->birthdate->format('m/d/Y')); ?></td>
                    <td class="userPhonenumber"><?php echo e($user->phone_number); ?></td>
                </tr>
        </table>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hoanganh\wtf1\laravel_HoangAnh\laravel_HoangAnh\resources\views/pages/info.blade.php ENDPATH**/ ?>