<nav class="navbar navbar-expand d-flex flex-column align-item-start" id="sidebar">
    <a href="#" class="navbar-brand text-light mb-4">
        <div class="display-5 font-weight-bold">TMA</div>
    </a>
    <ul class="navbar-nav d-flex flex-column  w-100">
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->is_admin): ?>
            <li class="nav-item w-100 <?php echo e(Route::is('equipment') ? 'nav-item-active' : ''); ?>">
                <a href="<?php echo e(route('equipment')); ?>" class="nav-link text-light pl-4">Equipments</a>
            </li>
            <li class="nav-item w-100 <?php echo e(Route::is('category') ? 'nav-item-active' : ''); ?>">
                <a href="<?php echo e(route('category')); ?>" class="nav-link text-light pl-4">Categories</a>
            </li>
            <li class="nav-item w-100 <?php echo e(Route::is('user') ? 'nav-item-active' : ''); ?>">
                <a href="<?php echo e(route('user')); ?>" class="nav-link text-light pl-4">Users</a>
            </li>
            <?php endif; ?>
        <?php endif; ?>
        <li class="nav-item w-100 <?php echo e(Route::is('myEquipments') ? 'nav-item-active' : ''); ?>">
            <a href="<?php echo e(route('myEquipments')); ?>" class="nav-link text-light pl-4">My Equipments</a>
        </li>
        <li class="nav-item w-100 <?php echo e(Route::is('info') ? 'nav-item-active' : ''); ?>">
            <a href="<?php echo e(route('info')); ?>" class="nav-link text-light pl-4">My info</a>
        </li>
        <li class="nav-item w-100">
            <a href="<?php echo e(route('logout')); ?>" class="nav-link text-light pl-4">Logout</a>
        </li>
    </ul>
</nav>
<?php /**PATH D:\hoanganh\wtf1\laravel_HoangAnh\laravel_HoangAnh\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>